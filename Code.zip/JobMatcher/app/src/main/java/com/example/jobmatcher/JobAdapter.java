package com.example.jobmatcher;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

/**
 * An {@link JobAdapter} knows how to create a list item layout for each earthquake
 * in the data source (a list of {@link Job} objects).
 *
 * These list item layouts will be provided to an adapter view like ListView
 * to be displayed to the user.
 */

public class JobAdapter extends ArrayAdapter<Job> {

    /**
     * Constructs a new {@link JobAdapter}.
     *
     * @param context of the app
     * @param jobs is the list of jobs, which is the data source of the adapter
     */
    public JobAdapter(Context context, List<Job> jobs) {
        super(context, 0, jobs);
    }

    /**
     * Returns a list item view that displays information about the job at the given position
     * in the list of jobs.
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.job_list_item, parent, false);
        }

        // Find the job at the given position in the list of jobs
        Job currentJob = getItem(position);

        // Find the TextView with view ID role
        TextView titleView = (TextView) listItemView.findViewById(R.id.role);
        titleView.setText(currentJob.getTitle());

        // Find the TextView with view ID company
        TextView companyView = (TextView) listItemView.findViewById(R.id.company);
        companyView.setText(currentJob.getCompanyName());

        // Find the TextView with view ID location
        TextView locationView = (TextView) listItemView.findViewById(R.id.location);
        locationView.setText(currentJob.getLocation());

        TextView jobType = (TextView) listItemView.findViewById(R.id.jobType);
        jobType.setText(currentJob.getJobType());

        TextView viaTextView = (TextView) listItemView.findViewById(R.id.viaTv);
        viaTextView.setText(currentJob.getVia());

        ImageView imageView = (ImageView) listItemView.findViewById(R.id.jobImgView);
        Glide.with(getContext())
                .load(currentJob.getThumbnail())
                .placeholder(R.drawable.default_logo)
                .error(R.drawable.default_logo)
                .into(imageView);

        return listItemView;
    }
}
