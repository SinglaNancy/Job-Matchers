package com.example.jobmatcher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button searchButton = (Button)findViewById(R.id.searchButton);
        EditText jobRoleEt = (EditText)findViewById(R.id.post);
        EditText jobLocationEt = (EditText)findViewById(R.id.location);
        Spinner spinner = (Spinner) findViewById(R.id.spinnerJobTypes);

        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("Full-Time");
        categories.add("Part-Time");
        categories.add("Contractor");
        categories.add("Internship");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner.setPrompt("Job Type");


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String jobLocation = jobLocationEt.getText().toString();
                String jobRole = jobRoleEt.getText().toString();
                String jobType = spinner.getSelectedItem().toString();
                if(jobType.equals("Full-Time")){
                    jobType = "FULLTIME";
                }if(jobType.equals("Part-Time")){
                    jobType = "PARTTIME";
                }if(jobType.equals("Internship")){
                    jobType = "INTERN";
                }if(jobType.equals("Contractor")){
                    jobType = "CONTRACTOR";
                }


                Intent intent = new Intent(MainActivity.this,JobActivity.class);
                Bundle extras = new Bundle();

                extras.putString("JOB_ROLE",jobRole);
                extras.putString("JOB_LOCATION",jobLocation);
                extras.putString("JOB_TYPE",jobType);

                intent.putExtras(extras);
                startActivity(intent);
            }
        });
    }
}