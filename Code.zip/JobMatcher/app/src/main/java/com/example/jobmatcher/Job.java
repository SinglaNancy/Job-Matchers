package com.example.jobmatcher;

import android.location.Location;

/**
 * An {@link Job} object contains information related to a single earthquake.
 */
public class Job {

    /** Title of the Job */
    private String mTitle;

    /** Company Name of the Job */
    private String companyName;

    /** Location of the Job */
    private String mLocation;

    /** Description of the Job */
    private String jd;

    /** job type */
    private String mJobType;

    /** id of the Job */
    private String mJobId;

    /** url of the Job */
    private String mUrl;

    private String mVia;

    private String mThumbnail;

    /**
     * Constructs a new {@link Job} object.
     */
    public Job(String title, String company_name, String location,String jobType,String jobId,String via,String thumbnail) {
        mTitle = title;
        companyName = company_name;
        mLocation = location;
        mJobId = jobId;
        mJobType = jobType;
        mVia = via;
        mThumbnail = thumbnail;
    }

    /**
     * Returns the title of the job.
     */
    public String getTitle() {
        return mTitle;
    }

    /**
     * Returns the company name of the job.
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Returns the location of the job.
     */
    public String getLocation() {
        return mLocation;
    }

    public String getJobType() {
        return mJobType;
    }


    /**
     * Returns the id of the job.
     */
    public String getJobId() {
        return mJobId;
    }

    public String getVia() {
        return mVia;
    }
    public String getThumbnail() {
        return mThumbnail;
    }

    /**
     * Returns the website URL to find more information about the earthquake.
     */
    public String getUrl() {
        return mUrl;
    }
}
